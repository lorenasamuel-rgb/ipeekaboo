-- Optional persistence for scan reports.
create table if not exists scans (
  id uuid primary key default gen_random_uuid(),
  app_name text,
  bundle_id text,
  version text,
  verdict text,
  score int,
  report jsonb not null,
  created_at timestamptz default now()
);

alter table scans enable row level security;

-- Demo policy: anyone with the anon key may insert and read their inserts.
-- Tighten to auth.uid() = user_id once you add Supabase Auth.
create policy "anon insert" on scans for insert to anon with check (true);
create policy "anon read"   on scans for select to anon using (true);
