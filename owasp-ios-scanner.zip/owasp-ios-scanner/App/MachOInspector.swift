import Foundation

// Lightweight, best-effort Mach-O inspection for binary-protection signals (OWASP M7).
// Returns nil for anything it can't confidently parse — never throws.
struct MachOInspector {

    struct Result {
        var isPIE: Bool?
        var isEncrypted: Bool?
    }

    private static let MH_MAGIC_64: UInt32   = 0xFEEDFACF
    private static let MH_CIGAM_64: UInt32   = 0xCFFAEDFE
    private static let FAT_MAGIC: UInt32      = 0xCAFEBABE
    private static let FAT_CIGAM: UInt32      = 0xBEBAFECA
    private static let MH_PIE: UInt32         = 0x00200000
    private static let LC_ENCRYPTION_INFO_64: UInt32 = 0x2C

    static func inspect(_ data: Data) -> Result {
        var result = Result()
        guard data.count > 32 else { return result }

        var offset = 0
        let magic = readU32(data, 0, bigEndian: false)

        // Fat binary: jump to the first architecture slice.
        if magic == FAT_MAGIC || magic == FAT_CIGAM {
            let big = magic == FAT_MAGIC // fat headers are big-endian
            let nfat = readU32(data, 4, bigEndian: big)
            guard nfat > 0, data.count > 8 + 20 else { return result }
            // fat_arch: cputype(4) cpusubtype(4) offset(4) size(4) align(4)
            let archOffset = readU32(data, 8 + 8, bigEndian: big)
            offset = Int(archOffset)
            guard offset + 32 <= data.count else { return result }
        }

        let sliceMagic = readU32(data, offset, bigEndian: false)
        guard sliceMagic == MH_MAGIC_64 || sliceMagic == MH_CIGAM_64 else { return result }
        let big = sliceMagic == MH_CIGAM_64

        // mach_header_64: magic(4) cputype(4) cpusubtype(4) filetype(4) ncmds(4) sizeofcmds(4) flags(4) reserved(4)
        let ncmds = readU32(data, offset + 16, bigEndian: big)
        let flags = readU32(data, offset + 24, bigEndian: big)
        result.isPIE = (flags & MH_PIE) != 0

        // Walk load commands looking for encryption info.
        var cmdOffset = offset + 32
        var encrypted = false
        var i: UInt32 = 0
        while i < ncmds && cmdOffset + 8 <= data.count {
            let cmd = readU32(data, cmdOffset, bigEndian: big)
            let cmdSize = readU32(data, cmdOffset + 4, bigEndian: big)
            if cmdSize < 8 { break }
            if cmd == LC_ENCRYPTION_INFO_64, cmdOffset + 20 <= data.count {
                let cryptId = readU32(data, cmdOffset + 16, bigEndian: big)
                if cryptId != 0 { encrypted = true }
            }
            cmdOffset += Int(cmdSize)
            i += 1
        }
        result.isEncrypted = encrypted
        return result
    }

    private static func readU32(_ data: Data, _ at: Int, bigEndian: Bool) -> UInt32 {
        guard at + 4 <= data.count else { return 0 }
        let b = [UInt8](data[data.startIndex + at ..< data.startIndex + at + 4])
        if bigEndian {
            return (UInt32(b[0]) << 24) | (UInt32(b[1]) << 16) | (UInt32(b[2]) << 8) | UInt32(b[3])
        } else {
            return (UInt32(b[3]) << 24) | (UInt32(b[2]) << 16) | (UInt32(b[1]) << 8) | UInt32(b[0])
        }
    }
}
