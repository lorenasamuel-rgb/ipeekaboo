import Foundation

// Evidence extracted on-device from the .ipa and sent to the Supabase edge function.
struct Evidence: Codable {
    var appName: String
    var bundleId: String
    var version: String
    var minimumOSVersion: String
    var atsAllowsArbitraryLoads: Bool
    var atsExceptionDomains: [String]
    var urlSchemes: [String]
    var permissionDescriptions: [String: String]   // e.g. NSCameraUsageDescription -> "..."
    var fileSharingEnabled: Bool
    var frameworks: [String]
    var hasEmbeddedProvision: Bool
    var isPIE: Bool?
    var isEncrypted: Bool?
    var suspiciousStrings: [String]                 // capped sample of flagged binary strings
    var binarySizeBytes: Int
}

struct Finding: Codable, Identifiable {
    var id = UUID()
    var masvsId: String        // "M5"
    var category: String       // "M5: Insecure Communication"
    var severity: String       // critical | high | medium | low
    var title: String
    var evidence: String
    var recommendation: String
    var impact: String

    enum CodingKeys: String, CodingKey {
        case masvsId, category, severity, title, evidence, recommendation, impact
    }
}

struct ScanReport: Codable, Identifiable {
    var id = UUID()
    var verdict: String        // critical | high | medium | low | clean
    var score: Int             // 0-100 (higher = safer)
    var summary: String
    var findings: [Finding]
    var goodPractices: [String]

    // Filled in on-device from the evidence (not trusted from the model).
    var appName: String = ""
    var bundleId: String = ""
    var version: String = ""
    var scannedAt: Date = Date()

    enum CodingKeys: String, CodingKey {
        case verdict, score, summary, findings, goodPractices
    }
}
