import SwiftUI

enum Theme {
    static let bg        = Color(hex: 0x0A0D14)
    static let surface   = Color(hex: 0x141A26)
    static let surface2  = Color(hex: 0x1B2333)
    static let border    = Color(hex: 0x263047)
    static let text      = Color(hex: 0xE7ECF5)
    static let text2     = Color(hex: 0x93A0B8)
    static let text3     = Color(hex: 0x5D6980)
    static let accent    = Color(hex: 0x7B6BF2)
    static let accent2   = Color(hex: 0x9A8DF6)

    static func severityColor(_ s: String) -> Color {
        switch s.lowercased() {
        case "critical": return Color(hex: 0xFF5F56)
        case "high":     return Color(hex: 0xEC6A52)
        case "medium":   return Color(hex: 0xE5A63C)
        case "low":      return Color(hex: 0x5B9BF5)
        default:         return Color(hex: 0x3FBF8F)
        }
    }
}

extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(.sRGB,
                  red:   Double((hex >> 16) & 0xff) / 255,
                  green: Double((hex >> 8) & 0xff) / 255,
                  blue:  Double(hex & 0xff) / 255,
                  opacity: alpha)
    }
}
