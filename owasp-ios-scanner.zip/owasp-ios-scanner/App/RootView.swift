import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            ScanView()
                .tabItem { Label("Scan", systemImage: "shield.lefthalf.filled") }
            AboutView()
                .tabItem { Label("About", systemImage: "info.circle") }
        }
        .tint(Theme.accent2)
    }
}

struct AboutView: View {
    private let items: [(String, String)] = [
        ("M1", "Improper Credential Usage"),
        ("M2", "Inadequate Supply Chain Security"),
        ("M3", "Insecure Authentication/Authorization"),
        ("M4", "Insufficient Input/Output Validation"),
        ("M5", "Insecure Communication"),
        ("M6", "Inadequate Privacy Controls"),
        ("M7", "Insufficient Binary Protections"),
        ("M8", "Security Misconfiguration"),
        ("M9", "Insecure Data Storage"),
        ("M10", "Insufficient Cryptography")
    ]

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("What this checks").font(.system(size: 20, weight: .bold))
                        .foregroundStyle(Theme.text)
                    Text("Findings are mapped to the OWASP Mobile Top 10 (2024).")
                        .font(.system(size: 13)).foregroundStyle(Theme.text2)
                    ForEach(items, id: \.0) { item in
                        HStack(spacing: 12) {
                            Text(item.0).font(.system(size: 12, weight: .bold, design: .monospaced))
                                .foregroundStyle(Theme.accent2).frame(width: 34, alignment: .leading)
                            Text(item.1).font(.system(size: 13)).foregroundStyle(Theme.text)
                            Spacer()
                        }
                        .padding(12)
                        .background(RoundedRectangle(cornerRadius: 10).fill(Theme.surface))
                    }
                    Text("Analysis is advisory static review of the app package — Info.plist, ATS config, frameworks, binary strings and Mach-O flags. It is not a full manual penetration test.")
                        .font(.system(size: 11)).foregroundStyle(Theme.text3).padding(.top, 6)
                }.padding(18)
            }
        }
    }
}
