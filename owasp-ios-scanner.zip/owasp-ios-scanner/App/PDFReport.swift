import UIKit

enum PDFReport {

    static func write(_ report: ScanReport) -> URL? {
        let data = renderPDF(html: html(for: report))
        let name = "OWASP-Scan-\(report.appName.replacingOccurrences(of: " ", with: "_"))-\(Int(Date().timeIntervalSince1970)).pdf"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do { try data.write(to: url); return url } catch { return nil }
    }

    private static func renderPDF(html: String) -> Data {
        let fmt = UIMarkupTextPrintFormatter(markupText: html)
        let renderer = UIPrintPageRenderer()
        renderer.addPrintFormatter(fmt, startingAtPageAt: 0)

        let page = CGRect(x: 0, y: 0, width: 595.2, height: 841.8) // A4 @72dpi
        let printable = page.insetBy(dx: 36, dy: 36)
        renderer.setValue(page, forKey: "paperRect")
        renderer.setValue(printable, forKey: "printableRect")

        let out = NSMutableData()
        UIGraphicsBeginPDFContextToData(out, page, nil)
        renderer.prepare(forDrawingPages: NSRange(location: 0, length: renderer.numberOfPages))
        for i in 0..<renderer.numberOfPages {
            UIGraphicsBeginPDFPage()
            renderer.drawPage(at: i, in: UIGraphicsGetPDFContextBounds())
        }
        UIGraphicsEndPDFContext()
        return out as Data
    }

    private static func esc(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
         .replacingOccurrences(of: "<", with: "&lt;")
         .replacingOccurrences(of: ">", with: "&gt;")
    }

    private static func color(_ sev: String) -> String {
        switch sev.lowercased() {
        case "critical": return "#D63A32"
        case "high": return "#C24A34"
        case "medium": return "#B67F1E"
        case "low": return "#2E6FB8"
        default: return "#1F8F66"
        }
    }

    private static func html(for r: ScanReport) -> String {
        let df = DateFormatter(); df.dateStyle = .medium; df.timeStyle = .short
        var body = """
        <style>
          body{font-family:-apple-system,Helvetica,sans-serif;color:#1a1a1a;padding:0 4px}
          h1{font-size:22px;margin:0 0 2px} .sub{color:#666;font-size:12px;margin:0 0 16px}
          .verdict{font-size:15px;font-weight:700;padding:10px 12px;border-radius:8px;background:#f2f2f2;margin:0 0 14px}
          .summary{font-size:13px;line-height:1.5;margin:0 0 18px}
          h2{font-size:15px;border-bottom:1px solid #ddd;padding-bottom:5px;margin:20px 0 10px}
          .f{border-left:4px solid #ccc;padding:8px 12px;margin:0 0 12px;background:#fafafa;border-radius:0 6px 6px 0}
          .sev{font-size:10px;font-weight:700;color:#fff;padding:2px 7px;border-radius:4px}
          .cat{color:#555;font-size:11px;font-weight:600;margin:4px 0}
          .ttl{font-size:14px;font-weight:600;margin:2px 0}
          .lbl{font-size:10px;font-weight:700;color:#888;text-transform:uppercase;margin-top:6px}
          .val{font-size:12px;line-height:1.45}
          li{font-size:12px;margin:3px 0}
        </style>
        <h1>OWASP Mobile Top 10 — Scan Report</h1>
        <p class="sub">\(esc(r.appName)) · \(esc(r.bundleId)) · v\(esc(r.version)) · \(df.string(from: Date()))</p>
        <div class="verdict">Verdict: \(r.verdict.capitalized) &nbsp;·&nbsp; Safety score: \(r.score)/100</div>
        <p class="summary">\(esc(r.summary))</p>
        <h2>Findings (\(r.findings.count))</h2>
        """

        if r.findings.isEmpty { body += "<p class='val'>No findings.</p>" }
        for f in r.findings {
            body += """
            <div class="f" style="border-left-color:\(color(f.severity))">
              <span class="sev" style="background:\(color(f.severity))">\(f.severity.uppercased())</span>
              <div class="cat">\(esc(f.category))</div>
              <div class="ttl">\(esc(f.title))</div>
              <div class="lbl">Evidence</div><div class="val">\(esc(f.evidence))</div>
              <div class="lbl">Fix</div><div class="val">\(esc(f.recommendation))</div>
              <div class="lbl">Impact</div><div class="val">\(esc(f.impact))</div>
            </div>
            """
        }

        if !r.goodPractices.isEmpty {
            body += "<h2>Good practices found</h2><ul>"
            for g in r.goodPractices { body += "<li>\(esc(g))</li>" }
            body += "</ul>"
        }
        body += "<p class='sub' style='margin-top:24px'>Advisory static analysis. Not a substitute for a full manual penetration test.</p>"
        return body
    }
}
