import Foundation

// 1. Create a Supabase project.  2. Paste your project URL + anon key below.
enum SupabaseConfig {
    static let url     = "https://YOUR_PROJECT.supabase.co"
    static let anonKey = "YOUR_SUPABASE_ANON_KEY"
}

enum ServiceError: LocalizedError {
    case notConfigured
    case badResponse(Int, String)
    case decodeFailed

    var errorDescription: String? {
        switch self {
        case .notConfigured: return "Add your Supabase URL and anon key in SupabaseConfig."
        case .badResponse(let code, let msg): return "Analysis service error (\(code)). \(msg)"
        case .decodeFailed: return "The report from the service could not be read."
        }
    }
}

struct SupabaseService {

    static func analyze(_ evidence: Evidence) async throws -> ScanReport {
        guard !SupabaseConfig.url.contains("YOUR_PROJECT") else { throw ServiceError.notConfigured }

        let endpoint = URL(string: "\(SupabaseConfig.url)/functions/v1/analyze-ipa")!
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.timeoutInterval = 90
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
        req.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        req.httpBody = try JSONEncoder().encode(evidence)

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw ServiceError.badResponse(-1, "") }
        guard http.statusCode == 200 else {
            throw ServiceError.badResponse(http.statusCode, String(data: data, encoding: .utf8) ?? "")
        }

        do {
            var report = try JSONDecoder().decode(ScanReport.self, from: data)
            report.appName = evidence.appName
            report.bundleId = evidence.bundleId
            report.version = evidence.version
            return report
        } catch {
            throw ServiceError.decodeFailed
        }
    }
}
