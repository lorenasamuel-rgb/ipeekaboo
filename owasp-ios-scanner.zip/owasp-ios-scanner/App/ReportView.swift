import SwiftUI

struct ReportView: View {
    let report: ScanReport
    @State private var pdfURL: URL?
    @State private var showShare = false

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 16) {
                    verdictCard
                    if !report.summary.isEmpty { summaryCard }
                    if !report.findings.isEmpty { findingsSection }
                    if !report.goodPractices.isEmpty { goodSection }
                    downloadButton
                }
                .padding(18)
            }
        }
        .navigationTitle(report.appName.isEmpty ? "Report" : report.appName)
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showShare) {
            if let pdfURL { ShareSheet(items: [pdfURL]) }
        }
    }

    private var verdictColor: Color {
        report.verdict.lowercased() == "clean" ? Theme.severityColor("clean")
            : Theme.severityColor(report.verdict)
    }

    private var verdictCard: some View {
        HStack(spacing: 14) {
            Image(systemName: report.verdict.lowercased() == "clean"
                  ? "checkmark.shield.fill" : "exclamationmark.shield.fill")
                .font(.system(size: 30)).foregroundStyle(verdictColor)
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(report.verdict.lowercased() == "clean"
                         ? "No blocking issues" : "\(report.verdict.capitalized) risk")
                        .font(.system(size: 16, weight: .bold)).foregroundStyle(Theme.text)
                    Spacer()
                    Text("\(report.score)").font(.system(size: 24, weight: .heavy))
                        .foregroundStyle(Theme.text)
                    + Text("/100").font(.system(size: 12, weight: .medium))
                        .foregroundStyle(Theme.text3)
                }
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.08))
                        Capsule().fill(verdictColor)
                            .frame(width: geo.size.width * CGFloat(max(0, min(100, report.score))) / 100)
                    }
                }.frame(height: 6)
            }
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 16).fill(Theme.surface))
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(verdictColor.opacity(0.4)))
    }

    private var summaryCard: some View {
        Text(report.summary).font(.system(size: 14)).foregroundStyle(Theme.text)
            .frame(maxWidth: .infinity, alignment: .leading).padding(15)
            .background(RoundedRectangle(cornerRadius: 14).fill(Theme.surface))
    }

    private var findingsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionHead("Findings", systemImage: "ladybug.fill", count: report.findings.count)
            ForEach(report.findings) { f in FindingCard(finding: f) }
        }
    }

    private var goodSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionHead("Good practices found", systemImage: "checkmark.seal.fill", count: nil)
            ForEach(Array(report.goodPractices.enumerated()), id: \.offset) { _, g in
                HStack(alignment: .top, spacing: 9) {
                    Image(systemName: "checkmark").font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Theme.severityColor("clean")).padding(.top, 3)
                    Text(g).font(.system(size: 13)).foregroundStyle(Theme.text2)
                    Spacer()
                }
            }
        }
        .padding(15).frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14).fill(Theme.surface))
    }

    private func sectionHead(_ title: String, systemImage: String, count: Int?) -> some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage).font(.system(size: 13)).foregroundStyle(Theme.accent2)
            Text(title).font(.system(size: 15, weight: .semibold)).foregroundStyle(Theme.text)
            if let count { Text("\(count)").font(.system(size: 12)).foregroundStyle(Theme.text3) }
            Spacer()
        }
    }

    private var downloadButton: some View {
        Button {
            pdfURL = PDFReport.write(report)
            if pdfURL != nil { showShare = true }
        } label: {
            Label("Download report (PDF)", systemImage: "square.and.arrow.down")
                .font(.system(size: 15, weight: .semibold))
                .frame(maxWidth: .infinity).padding(14)
                .background(RoundedRectangle(cornerRadius: 12).fill(Theme.accent))
                .foregroundStyle(.white)
        }
        .padding(.top, 4)
    }
}

struct FindingCard: View {
    let finding: Finding
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 8) {
                Text(finding.severity.uppercased())
                    .font(.system(size: 9, weight: .bold)).tracking(0.5)
                    .padding(.horizontal, 7).padding(.vertical, 4)
                    .background(Capsule().fill(Theme.severityColor(finding.severity).opacity(0.18)))
                    .foregroundStyle(Theme.severityColor(finding.severity))
                Text(finding.title).font(.system(size: 14, weight: .medium))
                    .foregroundStyle(Theme.text)
                Spacer()
            }
            Text(finding.category).font(.system(size: 10, weight: .semibold))
                .foregroundStyle(Theme.accent2)
            if !finding.evidence.isEmpty { kv("Evidence", finding.evidence, Theme.text2) }
            if !finding.recommendation.isEmpty { kv("Fix", finding.recommendation, Theme.severityColor("clean")) }
            if !finding.impact.isEmpty { kv("Impact", finding.impact, Theme.text3) }
        }
        .padding(14).frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 13).fill(Theme.surface))
        .overlay(alignment: .leading) {
            RoundedRectangle(cornerRadius: 2).fill(Theme.severityColor(finding.severity))
                .frame(width: 3).padding(.vertical, 12)
        }
    }

    private func kv(_ label: String, _ value: String, _ labelColor: Color) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label.uppercased()).font(.system(size: 9, weight: .semibold)).tracking(0.4)
                .foregroundStyle(labelColor)
            Text(value).font(.system(size: 12.5)).foregroundStyle(Theme.text2)
        }
    }
}

import UIKit
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}
