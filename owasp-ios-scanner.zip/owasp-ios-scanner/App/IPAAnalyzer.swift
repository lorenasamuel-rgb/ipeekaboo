import Foundation
import ZIPFoundation

enum AnalyzerError: LocalizedError {
    case unzipFailed
    case noAppBundle
    case noInfoPlist

    var errorDescription: String? {
        switch self {
        case .unzipFailed: return "That file couldn't be unpacked. Make sure it's a valid .ipa."
        case .noAppBundle: return "No app bundle found inside the .ipa (expected Payload/App.app)."
        case .noInfoPlist: return "The app's Info.plist could not be read."
        }
    }
}

struct IPAAnalyzer {

    static func analyze(ipaURL: URL) throws -> Evidence {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("scan-\(UUID().uuidString)")
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        do {
            try fm.unzipItem(at: ipaURL, to: work)
        } catch {
            throw AnalyzerError.unzipFailed
        }

        let payload = work.appendingPathComponent("Payload")
        let entries = (try? fm.contentsOfDirectory(at: payload, includingPropertiesForKeys: nil)) ?? []
        guard let appDir = entries.first(where: { $0.pathExtension == "app" }) else {
            throw AnalyzerError.noAppBundle
        }

        guard
            let plistData = try? Data(contentsOf: appDir.appendingPathComponent("Info.plist")),
            let plist = try? PropertyListSerialization.propertyList(from: plistData, options: [], format: nil) as? [String: Any]
        else { throw AnalyzerError.noInfoPlist }

        // --- Info.plist derived facts ---
        let appName = (plist["CFBundleDisplayName"] as? String)
            ?? (plist["CFBundleName"] as? String) ?? appDir.deletingPathExtension().lastPathComponent
        let bundleId = plist["CFBundleIdentifier"] as? String ?? "unknown"
        let shortVersion = plist["CFBundleShortVersionString"] as? String ?? "?"
        let build = plist["CFBundleVersion"] as? String ?? "?"
        let minOS = plist["MinimumOSVersion"] as? String ?? "?"
        let fileSharing = plist["UIFileSharingEnabled"] as? Bool ?? false

        var atsArbitrary = false
        var atsDomains: [String] = []
        if let ats = plist["NSAppTransportSecurity"] as? [String: Any] {
            atsArbitrary = ats["NSAllowsArbitraryLoads"] as? Bool ?? false
            if let ex = ats["NSExceptionDomains"] as? [String: Any] { atsDomains = Array(ex.keys) }
        }

        var schemes: [String] = []
        if let urlTypes = plist["CFBundleURLTypes"] as? [[String: Any]] {
            for t in urlTypes { schemes.append(contentsOf: (t["CFBundleURLSchemes"] as? [String]) ?? []) }
        }

        var permissions: [String: String] = [:]
        for (k, v) in plist where k.hasSuffix("UsageDescription") {
            permissions[k] = (v as? String) ?? ""
        }

        // --- Frameworks / embedded provision ---
        var frameworks: [String] = []
        let fwDir = appDir.appendingPathComponent("Frameworks")
        if let fws = try? fm.contentsOfDirectory(at: fwDir, includingPropertiesForKeys: nil) {
            frameworks = fws.map { $0.lastPathComponent }
        }
        let hasProvision = fm.fileExists(atPath: appDir.appendingPathComponent("embedded.mobileprovision").path)

        // --- Main binary: strings + Mach-O flags ---
        let exeName = plist["CFBundleExecutable"] as? String ?? appDir.deletingPathExtension().lastPathComponent
        let binaryURL = appDir.appendingPathComponent(exeName)
        let binaryData = (try? Data(contentsOf: binaryURL)) ?? Data()

        let macho = MachOInspector.inspect(binaryData)
        let suspicious = StringsScanner.flaggedStrings(in: binaryData)

        return Evidence(
            appName: appName,
            bundleId: bundleId,
            version: "\(shortVersion) (\(build))",
            minimumOSVersion: minOS,
            atsAllowsArbitraryLoads: atsArbitrary,
            atsExceptionDomains: atsDomains,
            urlSchemes: schemes,
            permissionDescriptions: permissions,
            fileSharingEnabled: fileSharing,
            frameworks: frameworks,
            hasEmbeddedProvision: hasProvision,
            isPIE: macho.isPIE,
            isEncrypted: macho.isEncrypted,
            suspiciousStrings: suspicious,
            binarySizeBytes: binaryData.count
        )
    }
}

// Extracts printable ASCII runs and flags ones that look like secrets / insecure endpoints.
struct StringsScanner {
    static func flaggedStrings(in data: Data, cap: Int = 40) -> [String] {
        let scanLimit = min(data.count, 8_000_000) // cap work at ~8 MB
        var runs: [String] = []
        var current: [UInt8] = []
        current.reserveCapacity(128)

        data.prefix(scanLimit).forEach { byte in
            if byte >= 0x20 && byte <= 0x7E {
                current.append(byte)
            } else {
                if current.count >= 6, let s = String(bytes: current, encoding: .ascii) { runs.append(s) }
                current.removeAll(keepingCapacity: true)
            }
        }
        if current.count >= 6, let s = String(bytes: current, encoding: .ascii) { runs.append(s) }

        let needles = ["http://", "AKIA", "-----BEGIN", "password", "passwd", "secret",
                       "api_key", "apikey", "api-key", "client_secret", "private_key",
                       "bearer ", "AIza", "sk_live", "sk-", "firebaseio.com", "amazonaws.com"]

        var flagged: [String] = []
        var seen = Set<String>()
        for s in runs {
            let low = s.lowercased()
            if needles.contains(where: { low.contains($0.lowercased()) }) {
                let trimmed = String(s.prefix(160))
                if !seen.contains(trimmed) {
                    seen.insert(trimmed)
                    flagged.append(trimmed)
                    if flagged.count >= cap { break }
                }
            }
        }
        return flagged
    }
}
